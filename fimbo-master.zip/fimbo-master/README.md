<img src="https://raw.githubusercontent.com/imfunniee/imfunniee.github.io/master/fimbo/img/fimbo.png"/>

# Fimbo ![GitHub stars](https://img.shields.io/github/stars/imfunniee/fimbo.svg?style=social) ![GitHub repo size](https://img.shields.io/github/repo-size/imfunniee/fimbo.svg?style=popout-square) ![GitHub](https://img.shields.io/github/license/imfunniee/fimbo.svg?style=popout-square) 

### Free to use Portfolio Templates

See them in action [here](https://imfunniee.github.io/fimbo)

Everyone needs a website to express themselves so i made free website templates. All you need to do is download them and customize them according to your need.

Have Fun. 😄


### Add your template

If you have a template you want to be on this repo create a PR
